#include<stdio.h>
int collatz_length(int starting_num)
{
	int length=1; //length is initailly set to 1 so that the starting number is also counted. 

	while(starting_num!=1)//loop to ensure that the calculation stops as soon as 1 is obtained
	{
		if(starting_num%2==0) // mod 2 is taken to figure out if num is even because all even numbers are divisible by 2 meaning remainder should be 0.
		{
			starting_num/=2; //divides starting num by 2 and the answer replaces starting num and if condition is satisfied, divides that new num by 2.	
		}
		else
		{
			starting_num=3*starting_num+1; //if number is odd, perform this calculation and answer replaces starting num. If condition is satisfied, performs that calculation for new num.
		}
		length++; //increases the length by 1 each time the aforementioned calculations are performed and new num is obtained.
	}
	return length;
	
}

int longest_collatz(int num)
{
	int longest_seq_num=0; //initialize to 0 as we will store the new longest num in the loop
	int max_length=0; //initialize to 0 as we will store the new max length in the loop
	int i;
	for(i=1;i<num;i++) //this loop runs for each number till the entered number
	{
		// Calculate the length of the Collatz sequence for the current number
		int length=collatz_length(i);
		if(length>max_length) //Condition to check if the current length is greater than the maximum length found till now.
		{
			max_length=length; //update maximum length if the new one is greater
			longest_seq_num=i; // Update the number with the longest sequence if this one has greater sequence.
		}
	}
	return longest_seq_num;	
	
}


int main()
{
	int num,length,longest_seq_num;
	printf("Enter the value of N:"); //prompt user to enter number for which collatz sequence has to be calculated
	scanf("%d",&num);
	longest_seq_num=longest_collatz(num); //to find the number with the longest collatz sequence
	length=collatz_length(longest_seq_num); //to calculate the length of the sequence for the longest number
	printf("The number with the longest Collatz sequence under %d is: %d\n",num,longest_seq_num);
	printf("The length of the Collatz Sequence is %d\n",length);
	return 0;
}
	
