#include<stdio.h>
void parse(int player1[5],int player2[5])
{
	int i;
	printf("Enter input of player 1:\n");
	for(i=0;i<5;i++) //takes input of 5 cards of player1
	{
		scanf("%d",&player1[i]);
	}
	
	printf("Enter input of player 2:\n");
	for(i=0;i<5;i++) //takes input of 5 cards of player2
	{
		scanf("%d",&player2[i]);
	}
}
int evaluate(int player[])
{
	int highest=0;
	int i;
	for (i=0;i<5;i++)  //loop to check who has the highest card
	{
        if (player[i]>highest) 
		{
            highest=player[i]; //updates highest
        }
	}
	return highest;
}
int compare(int player1[], int player2[])
{
	int win1=evaluate(player1);
	int win2=evaluate(player2);
	if (win1>win2) 
	{
        return 1; // Player 1 wins
    } 
	else if (win1<win2) 
	{
        return 2; // Player 2 wins
    } 
	else 
	{
        return 0; // It's a tie
    }
}
int main()
{
	int player1[5], player2[5];
    int player1_wins=0;
	int player2_wins=0;

	int i;
    for(i=0;i<5;i++) //evaluates winner for 5 hands 
	{
        parse(player1,player2);
        int winner=compare(player1,player2);

        if (winner==1) 
		{
            player1_wins++;
            printf("Player 1 wins.\n");
        } 
		else if (winner==2) 
		{
            player2_wins++;
            printf("Player 2 wins.\n");
        } 
		else 
		{
            printf("It's a tie.\n");
        }
    }
	//displays final winner who has won the most hands.
    printf("Player 1 wins: %d\n", player1_wins);
    printf("Player 2 wins: %d\n", player2_wins);

    return 0;
}
